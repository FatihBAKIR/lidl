#include <lidl/hashing.hpp>
#include <lidl/base.hpp>
#include <lidl/member.hpp>

namespace lidl {
hash_t hash(std::string_view) {
    return {};
}

hash_t hash(const base& b) {
    return b.stable_hash();
}
}