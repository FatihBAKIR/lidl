#include "lidl/hashing.hpp"
#include <lidl/member.hpp>

namespace lidl {
hash_t member::stable_hash() const {
    compound_hash ch;
    ch(type_);
    ch(nullable);
    return ch.value();
}
}