#pragma once

#include <cstdint>
#include <string_view>
#include <lidl/fwd.hpp>

namespace lidl {
struct hash_t {
    uint8_t buffer[32];
};

static hash_t hash(std::string_view);
static hash_t hash(const base& b);

struct compound_hash {
    template<class T>
    void operator()(const T& val);

    template<class T>
    void operator()(std::string_view name, const T& val);

    hash_t value() const;
};
} // namespace lidl