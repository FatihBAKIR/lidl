#pragma once

namespace lidl {
struct base;
struct member;
} // namespace lidl