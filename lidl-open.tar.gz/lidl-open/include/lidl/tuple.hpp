#pragma once

#include <lidl/basic.hpp>
#include <lidl/generics.hpp>

namespace lidl {
struct wire_tuple_type : generic_wire_type {
    using generic_wire_type::generic_wire_type;
};
}