use crate::MessageBuilder;

#[repr(C)]
pub struct String {
    len: i16
}