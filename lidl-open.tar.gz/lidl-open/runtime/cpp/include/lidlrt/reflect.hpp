#pragma once

namespace lidl {
struct member_info {
    const char* name;

};
}